<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class topup extends Model
{
    //
    protected $primaryKey = 'topup_id';
}
