<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use \App\category;
use \App\topup;
use \App\product;
use \App\discount;
use \App\purchase;
//use App\category;

class ShopController extends Controller
{
    
  /*  public function __construct(){
        $cat     = new category();
        $pur     = new purchase();
        $disc    = new discount();
        $topup   = new topup();
        $prod    = new product();
    }  
*/
    public function getCat(){
        $cat_read = $category::get()->where('cat_active_ind' , '=' , 'Y');
        return  response()->json($cat_read , 200); 
    }

    public function getProd($id){
        if(!empty($id)){
            $prod_read = product::select('prod_id' , 'prod_name' , 'prod_qty' , 'prod_retail')->where('prod_id' , '=' , $id)->get();    
        }else{
            $prod_read = product::select('prod_id' , 'prod_name' , 'prod_qty' , 'prod_retail')->where('prod_active_ind' , '=' , 'Y')->get();
        }
                            //get() || all()
        $response = [
            'products' => $prod_read /*$prod_read->prod_name/*,
            'prod_id' => $prod_read=>prod_qty,
            'prod_retail' => $prod_read=>prod_name,
            'prod_qty' =>$prod_read=>prod_name,*/
        ];
        return  response()->json($prod_read , 200); //$response
    }

    public function getDisc($id){
        $value = $id;
        $discount = 0.00;
        $discount_total = $value;
        if(!empty($value)){
            //dd("before");
            $disc_read = discount::select('disc_min_amt' , 'disc_max_amt' , 'disc_perc' )->where('disc_active_ind' , '=' , 'Y')->orderBy('disc_min_amt')->get();    
            //return response()->json($disc_read , 200); ;
            $results = count($disc_read);
            if($results >= 1 ){
                foreach($disc_read as $disc){
                    $min  = $disc['disc_min_amt'];
                    if($value < $min){
                        continue;
                    }
                    $max  = $disc['disc_max_amt'];
                    $perc = $disc['disc_perc'];
                    if($max == 0 || $value <= $max){
                        $discount_total = ($value - (($value * $perc) / 100));
                        $discount =  ($value * $perc) / 100;
                        break;
                    }/*else if($value <= $max){
                        $discount = ($value - (($value * $perc) / 100));
                        $discount =  ($value * $perc) / 100);
                        break;
                    }*/
                }
            }
            $response = [
                'disc_total' => $discount_total ,
                'disc_val' => $discount
            ];
        }else{
            $response = [
                'disc_total' => $discount_total ,
                'disc_val' => $discount
            ];
        }
        return response()->json($response , 200);
    }

    public function getAccbal($id){

        $topup_read = topup::select('topup_accbalance')->where('topup_user_id' , '=' , "$id")->orderBy("topup_id")->get()->last();
        if(!empty($topup_read->topup_accbalance)){
            $balance = $topup_read->topup_accbalance;
        }else{
            $balance = 0.00;
        }
        $response = [
            'balance' => (float)$balance//,
            //'topup_amount' => $topup_read 
        ];
        return  response()->json($response , 200);
    }
    
    public function getTransTop($id){
        $topup_read = topup::select('created_at','topup_amount','topup_accbalance')->where('topup_user_id' , '=' , "$id")->get();
        $response = [
            'topup_amount' => $topup_read/*,
            'created_at'   => $topup_read,*/ 
        ];
        return  response()->json($topup_read , 200);
    }
    
    public function getTransPur($id){
        $pur_read = purchase::select('pur_total','pur_qty','created_at')->where('pur_user_id' , '=' , "$id")->get();
        $response = [
            'purchases'  => $pur_read
        ];
        return  response()->json($pur_read , 200);
    }

    public function postPur(Request $request, $id){
        
        $pur     = new purchase();
        $pur->pur_prod_id = $request->pur_prod_id;
        $pur->pur_user_id = $id;//$request->pur_user_id;
        $pur->pur_qty     = $request->pur_qty;
        $pur->pur_disc    = (float)$request->pur_disc;
        $pur->pur_sale    = (float)$request->pur_sale;
        $pur->pur_total   = (float)$request->pur_total;
        $pur->save();
        $response = $pur->pur_id;
        return  response()->json($response , 200);
    }
    
    public function postTopup(Request $request, $id){
        $topup   = new topup();
        $topup->topup_user_id    = $id;//$request->topup_user_id;
        $topup->topup_amount     = (float)$request->topup_amount;
        $topup->topup_accbalance = (float)$request->topup_accbalance;
        $topup->save();
        $response = $topup->topup_id;
        return  response()->json($response , 200);
    }

    /*public function saveTopup(Request $request){
        //$user
        $topup   = new topup();
        $topup->topup_user_id    = $id;//$request->topup_user_id;
        $topup->topup_amount     = (float)$request->topup_amount;
        $topup->topup_accbalance = (float)$request->topup_accbalance;
        $topup->save();
        $response = $topup->topup_id;
        return  response()->json($response , 200);
    }*/

    public function savePur(){
        //dd(request()->all());
        $pur = new purchase();
        $pur->pur_prod_id = request('selectProd'); //$request->pur_prod_id;
        $pur->pur_user_id = request('user_id'); //$id;//$request->pur_user_id;
        $pur->pur_qty     = request('inputProdQty'); //$request->pur_qty;
        $pur->pur_disc    = request('inputProdDisc'); //(float)$request->pur_disc;
        $pur->pur_sale    = request('inputProdRetail'); //(float)$request->pur_sale;
        $pur->pur_total   = request('inputProdTotal'); //(float)$request->pur_total;
        $pur->save();
        $purResponse = $pur->pur_id;

        if(is_numeric($purResponse)){
            $id = request('user_id');
            $topup_read = topup::select('topup_accbalance')->where('topup_user_id' , '=' , "$id")->orderBy("topup_id")->get()->last();
            $balance    = $topup_read->topup_accbalance;
            $balance    = (float)$balance;
            $purchase   = request('inputProdTotal');
            $purchase   = (float)$purchase;
            $remaining_balance = $balance - $purchase;

            $topup   = new topup();
            $topup->topup_user_id    = $id;//$request->topup_user_id;
            $topup->topup_amount     = ($purchase * (-1));//(float)$request->topup_amount;
            $topup->topup_accbalance = $remaining_balance;//(float)$request->topup_accbalance;
            $topup->save();
            $topresponse = $topup->topup_id;
            if(is_numeric($topresponse)){
                $availqty = (request('inputAvailableQty')) - (request('inputProdQty'));
                $prodId   = request('selectProd');
                $prod = product::find($prodId);
                $prod->prod_qty = $availqty;
                $prod->save();
            }
        }

        return back()->with('success', "Order Completed  - Order # $purResponse "); // ->withInput()
        //return  response()->json($response , 200);
    }

    // Admin Data Saving
    public function saveProduct(){
        //$user
        $prod   = new product();
        $prod->cat_id           = 0;//Auth::user()->id;
        $prod->prod_qty         = request("inputProdQty");
        $prod->prod_name        = request("inputProdName");
        $prod->prod_active_ind  = request("inputProdActive");
        $prod->prod_cost        = request("inputProdCost");
        $prod->prod_retail      = request("inputProdRetail");
        $prod->save();
        $response = $prod->prod_id;
        return back()->with('success', "Record " . request('inputProdName') . " - $response Inserted"); // ->withInput()
        //return  response()->json($response , 200);
    }

    public function saveTopup(){
        $id = request('user_id');
        $tupupVal = request('inputTopupAmt');
        if(is_numeric($tupupVal) && ($tupupVal > 0 )){
            $topup_read = topup::select('topup_accbalance')->where('topup_user_id' , '=' , "$id")->orderBy("topup_id")->get()->last();
            //return $topup_read->topup_accbalance;//$id;//request()->all();

            if(!empty($topup_read->topup_accbalance)){
                $balance = $topup_read->topup_accbalance;
            }else{
                $balance = 0.00;
            }

            $newbalance = ((request('inputTopupAmt')) + $balance);

            $topup   = new topup();
            $topup->topup_user_id    = request('user_id');//$id;//$request->topup_user_id;
            $topup->topup_amount     = request('inputTopupAmt');//(float)$request->topup_amount;
            $topup->topup_accbalance = $newbalance;//(float)$request->topup_accbalance;
            $topup->save();
            $response = $topup->topup_id;
            return back()->with('success', "Top Success - New Balance : $newbalance"); // ->withInput()
            //return  response()->json($response , 200);
        }else{
            return redirect()->back()->with('error', "Top Failed - Numeric Values ONLY : $tupupVal" );
        }
        
    }
    

    public function saveCategory(){ //Request $request
        //$user
        //dd(request()->all());

        //if ( request()->has('weight') ){
            $cat   = new category();
            $cat->cat_id           = 0;//Auth::user()->id;
            $cat->cat_name        = request('inputCatName');//Input::get("inputCatName");
            $cat->cat_active_ind  = request('inputCatActive');//Input::get("inputCatActive");
            $cat->save();
            $response = $cat->cat_id;
            //Session::flash('message', "Record $response Inserted");
            return back()->with('success', "Record " . request('inputCatName') . " - $response Inserted"); // ->withInput()
            //return redirect('/category' , );
            //return response()->json($response , 200);
        //}
        //return "Failed to write";
    }

    public function saveDiscount(){
        //$user
        //console.log($request);
        $disc   = new discount();
        $disc->disc_min_amt    = request("inputDiscMin");
        $disc->disc_max_amt    = request("inputDiscMax");
        $disc->disc_perc       = request("inputDiscPerc");
        //$disc->disc_cat_id      = Input::get("inputProdCost");
        $disc->disc_active_ind = request("inputDiscActive");
        $disc->save();
        $response = $disc->disc_id;
        return back()->with('success', "Record $response Inserted"); // ->withInput()
        //return response()->json($response , 200);
    }

    


}
