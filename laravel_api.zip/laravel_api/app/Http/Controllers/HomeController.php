<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;
use App\topup;
use App\purchase;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->user()->authorizeRoles(['Admin'])){
            return view('admin/home');
        } else {   
            return view('user/home');
        }
    }

    public function products(Request $request)
    {
        if($request->user()->authorizeRoles(['Admin'])){
            return view('admin/products');
        } 
        return false;
    }

    public function discount(Request $request)
    {
        if($request->user()->authorizeRoles(['Admin'])){
            return view('admin/discount');
        } 
        return false;
    }

    public function category(Request $request)
    {
        if($request->user()->authorizeRoles(['Admin'])){
            return view('admin/category');
        } 
        return false;
    }

    public function shop(Request $request)
    {
        if($request->user()->authorizeRoles(['User'])){
            $products = product::select('prod_name','prod_id')->where('prod_active_ind', 'Y' )->orderBy('prod_name')->get();//->pluck('prod_name', 'prod_id');
            //dd($products);
            return view('user/shop',compact('products',$products));
        } 
        return false;
    }

    public function topup(Request $request)
    {
        if($request->user()->authorizeRoles(['User'])){
            return view('user/topup');
        } 
        return false;
    }

    public function transactions(Request $request)
    {
        if($request->user()->authorizeRoles(['User'])){
            $id = $request->user()->id;
            $topup_read = topup::select('topup_id','created_at','topup_amount','topup_accbalance')->where('topup_user_id' , '=' , "$id")->get();
            $pur_read   = purchase::select('pur_id','pur_total','pur_qty','created_at','pur_disc')->where('pur_user_id' , '=' , "$id")->get();
            
            $response = [
                'purchases' => $pur_read,
                'topups'    => $topup_read
            ];
            //$pur_read = response()->json($pur_read);
            //$topup_read = response()->json($topup_read);
            
            //dd($response);
            //return view('user/transactions')->with('result',$topup_read);
           return view('user/transactions', array('topup_read'=>$topup_read,'pur_read'=>$pur_read));
        } 
        return false;
    }

}
