<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDiscountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('discounts', function (Blueprint $table) {
            $table->increments('disc_id');
            $table->decimal('disc_min_amt',6,2)->default(0.00);
            $table->decimal('disc_max_amt',6,2)->default(0.00);
            $table->integer('disc_perc');
            $table->integer('disc_cat_id')->default(0);
            $table->string('disc_active_ind',3)->default('Y');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('discounts');
    }
}
