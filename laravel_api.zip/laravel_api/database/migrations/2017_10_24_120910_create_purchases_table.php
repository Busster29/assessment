<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePurchasesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchases', function (Blueprint $table) {
            $table->increments('pur_id');
            $table->integer('pur_prod_id')->default(0);
            $table->integer('pur_cat_id')->default(0);
            $table->integer('pur_user_id');
            $table->integer('pur_qty');
            $table->decimal('pur_disc')->default(0.00);
            $table->decimal('pur_sale',6,2)->default(0.00);
            $table->decimal('pur_total',6,2)->default(0.00);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchases');
    }
}
