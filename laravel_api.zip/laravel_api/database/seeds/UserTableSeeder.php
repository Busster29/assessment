<?php

use Illuminate\Database\Seeder;
use App\User;
use App\role;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin_role = role::where('name' , 'Admin')->first();
        $user_role = role::where('name' , 'User')->first();

        $user = new User();
        $user->name     = 'Muhammed'; 
        $user->password = bcrypt('Password');
        $user->email    = 'muhammedy.haet@gmail.com';
        $user->save();
        $user->roles()->attach($admin_role);

        $user2 = new User();
        $user2->name     = 'Muhammed';
        $user2->password = bcrypt('Password');
        $user2->email    = 'busster.18@gmail.com';
        $user2->save();
        $user2->roles()->attach($user_role);
    }
}
