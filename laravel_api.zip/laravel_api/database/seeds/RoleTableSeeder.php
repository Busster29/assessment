<?php

use Illuminate\Database\Seeder;
use App\role;


class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = new role();
        $role->name         = 'Admin';
        $role->description  = 'An Admin User';
        $role->save();

        $role2 = new role();
        $role2->name        = 'User';
        $role2->description = 'A Normal User';
        $role2->save();
    }
}
