<?php $__env->startSection('left_menu'); ?>
<li class="active"><a href="<?php echo e(route('products')); ?>">Products</a></li>
<li><a href="<?php echo e(route('discount')); ?>">Discounts</a></li>
<li><a href="<?php echo e(route('category')); ?>">Category</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-info"><?php echo e(\Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Capture Products Form</h3>
                </div>
                <div class="panel-body">
                    <form action="saveProduct" method="POST" class="form-horizontal">
                    <fieldset>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="inputProdQty" class="col-lg-2 control-label">Stock On Hand </label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputProdQty" id="inputProdQty" placeholder="Stock on Hand">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdName" class="col-lg-2 control-label">Product Name</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputProdName" id="inputProdName" placeholder="Product Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdActive" class="col-lg-2 control-label">Product Active</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputProdActive" id="inputProdActive" placeholder="Product Active">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdCost" class="col-lg-2 control-label">Product Cost</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputProdCost" id="inputProdCost" placeholder="Product Cost">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdRetail" class="col-lg-2 control-label">Product Retail</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputProdRetail" id="inputProdRetail" placeholder="Product Retail">
                            </div>
                        </div>

                        <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>