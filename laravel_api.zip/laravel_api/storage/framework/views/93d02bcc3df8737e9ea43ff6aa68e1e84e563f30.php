<?php $__env->startSection('left_menu'); ?>
<li><a href="<?php echo e(route('shop')); ?>">Shop</a></li>
<li class="active"><a href="<?php echo e(route('transactions')); ?>">trasactions</a></li>
<li><a href="<?php echo e(route('topup')); ?>">topup</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Transaction History
                </div>
                <div class="panel-body">
                    <h3>Purchase History</h3>
                    <br>
                    <form action="" class="form-horizontal" method="POST" >
                       <?php echo e(csrf_field()); ?>       
                       <input name='user_id' type="hidden" class="form-control" id="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                    </form>
                    <?php if(isset($pur_read)): ?>
                        <table class="table table-striped table-hover ">
                            <thead>
                                <tr>
                                <th>#</th>
                                <th>Date Purchased</th>
                                <th>Total Amount</th>
                                <th>Discount Amount</th>
                                <th>Qty</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $__currentLoopData = $pur_read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purvar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="info">   
                                        <td><?php echo e($purvar['pur_id']); ?></td>
                                        <td><?php echo e($purvar['created_at']); ?></td>
                                        <td><?php echo e($purvar['pur_total']); ?></td>
                                        <td><?php echo e($purvar['pur_disc']); ?></td>
                                        <td><?php echo e($purvar['pur_qty']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table> 
                    <?php endif; ?>
                    <br>
                    <h3> Topup History</h3>
                    <?php if(isset($topup_read)): ?>
                        <table class="table table-striped table-hover ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Topup Date</th>
                                    <th>Balancd B/F</th>
                                    <th>Topup Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $topup_read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topvar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="success">   
                                            <td><?php echo e($topvar['topup_id']); ?></td>
                                            <td><?php echo e($topvar['created_at']); ?></td>
                                            <td><?php echo e($topvar['topup_accbalance']); ?></td>
                                            <td><?php echo e($topvar['topup_amount']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table> 
                     <?php endif; ?>   
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    
    $(document).ready(function($) {
                userid = $("#user_id").val();
                $.get("http://localhost:8000/api/transtop/" + userid, function(trandata, status){
		            //console.log(trandata);
                    //$("#inputCurBal").val(data['balance']);
                });
                $.get("http://localhost:8000/api/transpur/" + userid, function(purdata, status){
		            //console.log(purdata);
                    //$("#inputCurBal").val(data['balance']);
                });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>