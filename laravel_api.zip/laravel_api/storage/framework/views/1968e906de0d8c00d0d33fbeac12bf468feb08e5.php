<?php $__env->startSection('left_menu'); ?>
<li><a href="<?php echo e(route('shop')); ?>">Shop</a></li>
<li><a href="<?php echo e(route('transactions')); ?>">trasactions</a></li>
<li class="active"><a href="<?php echo e(route('topup')); ?>">topup</a></li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-info"><?php echo e(\Session::get('success')); ?></div>
            <?php endif; ?>
              <?php if(\Session::has('error')): ?>
                <div class="alert alert-info"><?php echo e(\Session::get('error')); ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Topup Account Form</h3>
                </div>
                <div class="panel-body">
                    <form action="saveTopup" class="form-horizontal" method="POST" >
                    <fieldset>
                        <div class="form-group">
                            <label for="inputCurBal" class="col-lg-2 control-label">Current Balance</label>
                            <div class="col-lg-10">
                                <input type="text" readonly class="form-control" name="inputCurBal"  id="inputCurBal" >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputTopupAmt" class="col-lg-2 control-label">Topup Amount</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputTopupAmt" id="inputTopupAmt" placeholder="0.00">
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>

                       <input name='user_id' type="hidden" class="form-control" id="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                        <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button     type="submit" id='submit' class="btn btn-primary">Submit</button>
                        </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function($) {
                userid = $("#user_id").val();
                $.get("http://localhost:8000/api/bal/" + userid, function(data, status){
		            console.log(data);
                    $("#inputCurBal").val(data['balance']);
                });

                //$( "#inputTopupAmt" ).change(function() {
                $( "#submit" ).focus(function() {
                    var numb = $("#inputTopupAmt").val();
                    if($.isNumeric(numb)){
                        $("#inputTopupAmt").val((parseFloat(numb) || 0).toFixed(2));
                        $("#submit").removeAttr('disabled');
                    }else{
                        $("#inputTopupAmt").css({ "border": '#FF0000 1px solid'});
                        //alert("Your Amount must only contain digits!");
                    }		
			    });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>