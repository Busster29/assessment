<?php $__env->startSection('left_menu'); ?>
<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
<li class="active"><a href="<?php echo e(route('discount')); ?>">Discounts</a></li>
<li><a href="<?php echo e(route('category')); ?>">Category</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-info"><?php echo e(\Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Capture Discounts Form</h3>
                </div>
                <div class="panel-body">
                    <form action="saveDiscount" method="POST" class="form-horizontal">
                    <fieldset>
                        <div class="form-group">
                            <label for="inputDiscMin" class="col-lg-2 control-label">Disount Start Value</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputDiscMin" id="inputDiscMin" placeholder="Disount Start Value">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDiscMax" class="col-lg-2 control-label">Discount End Value</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputDiscMax" id="inputDiscMax" placeholder="Discount End Value">
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDiscPerc" class="col-lg-2 control-label">Discount Percentage</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputDiscPerc" id="inputDiscPerc" placeholder="Discount Percentage">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDiscActive" class="col-lg-2 control-label">Discount Active</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputDiscActive" id="inputDiscActive" placeholder="Discount Active">
                            </div>
                        </div>

                        <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>