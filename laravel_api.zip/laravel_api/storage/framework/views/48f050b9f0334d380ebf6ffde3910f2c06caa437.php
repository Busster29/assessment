<?php $__env->startSection('left_menu'); ?>
<li><a href="<?php echo e(route('products')); ?>">Products</a></li>
<li><a href="<?php echo e(route('discount')); ?>">Discounts</a></li>
<li class='active'><a href="<?php echo e(route('category')); ?>" >Category</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-info"><?php echo e(\Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Capture Categories Form</h3>
                </div>
                <div class="panel-body">
                    <form action="/saveCategory" method="POST" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <fieldset>
                        <div class="form-group">
                            <label for="inputCatName" class="col-lg-2 control-label">Category</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputCatName" id="inputCatName" placeholder="Category"  value="<?php echo e(old('inputCatName')); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputCatActive" class="col-lg-2 control-label">Active Indicator</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputCatActive" id="inputCatActive" placeholder="Active Indicator" value="<?php echo e(old('inputCatActive')); ?>">
                            </div>
                        </div>
                            
                        <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>