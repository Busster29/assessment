<?php

use Illuminate\Http\Request;
//use \App\category;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::get('/cat', [
    'uses' => 'ShopController@getCat'
]);

Route::get('/prod/{id?}', [
    'uses' => 'ShopController@getProd'
]);

Route::get('/disc/{id?}', [
    'uses' => 'ShopController@getdisc'
]);

Route::get('/bal/{id}', [
    'uses' => 'ShopController@getAccbal'
]);

Route::get('/transtop/{id}', [
    'uses' => 'ShopController@getTransTop'
]);

Route::get('/transpur/{id}', [
    'uses' => 'ShopController@getTransPur'
]);

Route::post('/pur/{id}', [
    'uses' => 'ShopController@postPur'
]);

Route::post('/topup/{id}', [
    'uses' => 'ShopController@postTopup'
]);