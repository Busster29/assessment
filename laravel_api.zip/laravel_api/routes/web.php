<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::get('/', function () {
    try {
        if (DB::connection()->getDatabaseName())
        {
           return 'Connected to the DB: ' . DB::connection()->getDatabaseName();
        }   
    } catch (\Exception $e) {
        dd("Could not connect to the database.  Please check your configuration.");
    }
    //return view('welcome');
});
*/


/*Route::get('/', function () {
    return view('home');
});



*/
/*

Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
*/
//display landing Page
Auth::routes();
Route::get('/', 'HomeController@index')->name('home');

//display User data
Auth::routes();
Route::get('/shop', 'HomeController@shop')->name('shop');

Auth::routes();
Route::get('/topup', 'HomeController@topup')->name('topup');

Auth::routes();
Route::get('/transactions', 'HomeController@transactions')->name('transactions');

// Display admin Data 

Auth::routes();
Route::get('/category', 'HomeController@category')->name('category');

Auth::routes();
Route::get('/products', 'HomeController@products')->name('products');

Auth::routes();
Route::get('/discount', 'HomeController@discount')->name('discount');

//Save Admin Data
Auth::routes();
Route::post('saveProduct', 'ShopController@saveProduct')->name('saveProduct');

Auth::routes();
Route::post('saveCategory', 'ShopController@saveCategory');//->name('saveCategory');

Auth::routes();
Route::post('saveDiscount', 'ShopController@saveDiscount')->name('saveDiscount');

Auth::routes();
Route::post('saveTopup', 'ShopController@saveTopup')->name('saveTopup');

auth::routes();
Route::post('savePur','ShopController@savePur')->name('savePur');