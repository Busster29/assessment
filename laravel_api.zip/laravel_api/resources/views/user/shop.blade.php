@extends('layouts.app')

@section('left_menu')
<li class="active"><a href="{{ route('shop') }}">Shop</a></li>
<li><a href="{{ route('transactions') }}">trasactions</a></li>
<li><a href="{{ route('topup') }}">topup</a></li>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            @if (\Session::has('success'))
                <div class="alert alert-info">{{ \Session::get('success') }}</div>
            @endif
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Purchases Form</h3>
                </div>
                <div class="panel-body">
                    <form action="savePur" class="form-horizontal" method="POST">
                    <fieldset>
                        <div class="form-group">
                            <label for="selectProd" class="col-lg-2 control-label">Select Product</label>
                            <div class="col-lg-10">
                                <select name='selectProd' class="form-control" id="selectProd">
                                <option value="0"> Select Product  </option>
                                    @foreach($products as $prod)
                                        <option value="{{$prod->prod_id}}">    {{$prod->prod_name}}    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputAvailableQty" class="col-lg-2 control-label">Available Quantity</label>
                            <div class="col-lg-10">
                                <input readonly type="text" class="form-control" name='inputAvailableQty' id="inputAvailableQty" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdQty" class="col-lg-2 control-label">Product Qty</label>
                            <div class="col-lg-10">
                                <input readonly type="text" class="form-control" name='inputProdQty' id="inputProdQty" placeholder="Product Qty" value=1>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdRetail" class="col-lg-2 control-label">Product Retail</label>
                            <div class="col-lg-10">
                                <input readonly type="text" class="form-control" name='inputProdRetail' id="inputProdRetail" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdDisc" class="col-lg-2 control-label">Order Discount</label>
                            <div class="col-lg-10">
                                <input readonly type="numbernumber" class="form-control" name='inputProdDisc' id="inputProdDisc" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputProdTotal" class="col-lg-2 control-label">Order Total</label>
                            <div class="col-lg-10">
                                <input readonly type="number" class="form-control" name='inputProdTotal' id="inputProdTotal" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputTopupBal" class="col-lg-2 control-label">Available Balance</label>
                            <div class="col-lg-10">
                                <input readonly type="number" class="form-control" name='inputTopupBal' id="inputTopupBal" placeholder="0.00">
                                {{ csrf_field() }}
                            </div>
                        </div>
                        <input type="hidden" class="form-control" name="user_id" id="user_id" value="{{ Auth::user()->id }}" >
                        <div class="form-group">
                            <div class="col-lg-10 col-lg-offset-2">
                                <button type="reset" class="btn btn-default">Cancel</button>
                                <button id="submit" type="submit" disabled='' class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function($) {
        $( "#selectProd" ).change(function() {
            selectedProd = $("#selectProd").val();
            if($("#selectProd").val() > 0 ){	
                console.log(selectedProd);	
                $.get("http://localhost:8000/api/prod/" + selectedProd, function(data, status){
		            //console.log(data[0]['prod_retail']);
                    $("#inputProdRetail").val(data[0]['prod_retail']);
                    $("#inputAvailableQty").val(data[0]['prod_qty']);
                    
                    $.get("http://localhost:8000/api/disc/" + data[0]['prod_retail'], function(disc, status){
                        $("#inputProdDisc").val(disc['disc_val']);
                        $("#inputProdTotal").val(disc['disc_total']);
		                //console.log(disc);    
                        if(balanceBf <= disc['disc_total']){
                            $("#submit").attr("disabled", true);
                            $("#inputTopupBal").css({ "border": '#FF0000 1px solid'});
                            alert('Please Topup - Insufficient Funds');        
                        }else{
                            $("#submit").removeAttr('disabled');
                        }
		            });    
		        });
            }else{
                $("#submit").attr("disabled", true);
                $("#selectProd").css({ "border": '#FF0000 1px solid'});
                alert('Please Select - Product');
            }
        });
    });

    userid = $('#user_id').val(); 
    $.get("http://localhost:8000/api/bal/" + userid, function(data, status){
        //console.log(data);
        $("#inputTopupBal").val(data['balance']);
        balanceBf = data['balance'];
    });
    var balanceBf;


    /*$.post('',
    {   'kes'   : data['quotes']['USDKES'], 	 
        'gbp'	: data['quotes']['USDGBP'], 	  
        'eur'   : data['quotes']['USDEUR'],
        'zar'	: data['quotes']['USDZAR'],
        'usd'	: data['quotes']['USDUSD'], 	
        '_token':$('input[name=_token]').val() }, function(data2) {
            if(data2=='Done'){
                //$("#tobuytab").removeClass('disabled');
                //$("#topaytab").removeClass('disabled');
                $("#apibutton").hide();
                $("#buthead").hide();
                alert('Exchange rates were imported');
                console.log(data2);
            }
        }
    );*/		 
</script>
@endsection

