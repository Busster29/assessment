@extends('layouts.app')

@section('left_menu')
<li><a href="{{ route('shop') }}">Shop</a></li>
<li class="active"><a href="{{ route('transactions') }}">trasactions</a></li>
<li><a href="{{ route('topup') }}">topup</a></li>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Transaction History
                </div>
                <div class="panel-body">
                    <h3>Purchase History</h3>
                    <br>
                    <form action="" class="form-horizontal" method="POST" >
                       {{ csrf_field() }}       
                       <input name='user_id' type="hidden" class="form-control" id="user_id" value="{{ Auth::user()->id }}" >
                    </form>
                    @if(isset($pur_read))
                        <table class="table table-striped table-hover ">
                            <thead>
                                <tr>
                                <th>#</th>
                                <th>Date Purchased</th>
                                <th>Total Amount</th>
                                <th>Discount Amount</th>
                                <th>Qty</th>
                                </tr>
                            </thead>
                            <tbody> 
                                @foreach($pur_read as $purvar)
                                    <tr class="info">   
                                        <td>{{$purvar['pur_id']}}</td>
                                        <td>{{$purvar['created_at']}}</td>
                                        <td>{{$purvar['pur_total']}}</td>
                                        <td>{{$purvar['pur_disc']}}</td>
                                        <td>{{$purvar['pur_qty']}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table> 
                    @endif
                    <br>
                    <h3> Topup History</h3>
                    @if(isset($topup_read))
                        <table class="table table-striped table-hover ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Topup Date</th>
                                    <th>Balancd B/F</th>
                                    <th>Topup Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($topup_read as $topvar)
                                    <tr class="success">   
                                            <td>{{$topvar['topup_id']}}</td>
                                            <td>{{$topvar['created_at']}}</td>
                                            <td>{{$topvar['topup_accbalance']}}</td>
                                            <td>{{$topvar['topup_amount']}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table> 
                     @endif   
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    
    $(document).ready(function($) {
                userid = $("#user_id").val();
                $.get("http://localhost:8000/api/transtop/" + userid, function(trandata, status){
		            //console.log(trandata);
                    //$("#inputCurBal").val(data['balance']);
                });
                $.get("http://localhost:8000/api/transpur/" + userid, function(purdata, status){
		            //console.log(purdata);
                    //$("#inputCurBal").val(data['balance']);
                });
    });

</script>

@endsection
