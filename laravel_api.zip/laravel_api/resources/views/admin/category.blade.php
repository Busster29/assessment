@extends('layouts.app')
@section('left_menu')
<li><a href="{{ route('products') }}">Products</a></li>
<li><a href="{{ route('discount') }}">Discounts</a></li>
<li class='active'><a href="{{ route('category') }}" >Category</a></li>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            @if (\Session::has('success'))
                <div class="alert alert-info">{{ \Session::get('success') }}</div>
            @endif
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>Capture Categories Form</h3>
                </div>
                <div class="panel-body">
                    <form action="/saveCategory" method="POST" class="form-horizontal">
                    {{ csrf_field() }}
                    <fieldset>
                        <div class="form-group">
                            <label for="inputCatName" class="col-lg-2 control-label">Category</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputCatName" id="inputCatName" placeholder="Category"  value="{{ old('inputCatName') }}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputCatActive" class="col-lg-2 control-label">Active Indicator</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" name="inputCatActive" id="inputCatActive" placeholder="Active Indicator" value="{{ old('inputCatActive') }}">
                            </div>
                        </div>
                            
                        <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-default">Cancel</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
