@extends('layouts.app')
@section('left_menu')
<li><a href="{{ route('products') }}">Products</a></li>
<li><a href="{{ route('discount') }}">Discounts</a></li>
<li><a href="{{ route('category') }}">Category</a></li>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <p>
                        Please select menu option for maintenance to be carried out.
                        <br><br>
                        This dashboard will be used to display an overview relevent information to the administrator.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
